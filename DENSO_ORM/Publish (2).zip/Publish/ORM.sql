create table tbl_KpiManHrs_Ratio_Type
(
RefNo int identity,
HeaderType varchar(100),
OrginalName varchar(100),
ReportType varchar(20),
NameType varchar(20)
)

alter table [dbo].[tbl_KPIEntry] add [NPDDirectHr] varchar(20),[NPDExcludHr] varchar(20)

alter table [dbo].[tbl_MachineGroup] add [Section] varchar(20)


GO
ALTER PROC [dbo].[Proc_KPIEntry]
(
@Slno int= null,
@MachineGroupName varchar(100)=null,
@MachineName varchar(100)=null,
@ModelName varchar(100)=null,
@TOTAL_MANPOWER_GIVEN_BY_COMPANY varchar(20)=null,
@ABSENT varchar(20)=null,
@INLINE_OPERATOR varchar(20) =null,
@OFFLINE_LINE_PARTS_FEEDER varchar(100)=null,
@OUTLINE_LINE_SUPPORTER varchar(100)=null,
@DIRECT_MANPOWER varchar(20)=null,
@SUPERVISOR varchar(20)=null,
@INLINE_MANPOWER varchar(20)=null,
@OFFLINE_LINE_PARTS_FEEDER_MANHOUR varchar(20)=null,
@OUTLINE_LINE_SUPPORTER_MANHOUR varchar(20)=null,
@SUPERVISOR_MANHOUR varchar(10)=null,
@INLINE_MANPOWER_TAKEN_FROM_BANK varchar(10)=null,
@INLINE_BORROWED_AFTER_MAN_POWER_BANKING varchar(10)=null,
@OFFLINE_MIZ_MANPOWER_TAKEN_FROM_BANK varchar(10)=null,
@OFFLINE_MIZ_BORROWED_AFTER_MAN_POWER_BANKING varchar(10)=null,
@OUTLINE_SUPPORTER_TAKEN_FROM_OTHER_LINES varchar(10)=null,
@DIRECT_MP_WORKED_IN_LINE_TL_GL_SL_QA_LOGISTICS_BELOW_AM varchar(10)=null,
@INLINE_MP_GIVEN_TO_BANK varchar(10)=null,
@OFFLINE_MIZ_GIVEN_TO_BANK varchar(10)=null,
@OUTLINE_SUPPORTER_LENDING varchar(10)=null,
@OFFLINE_MIZ_LENDING_AFTER_MAN_POWER_BANKING varchar(10)=null,
@INDIRECT_WORKED_IN_LINE_Prod_Logi_QA_above_AM_Other_dept_members varchar(10)=null,
@SHIFT_WORKIG_HRS varchar(10)=null,
@LUNCH_TIME_30_Minutes varchar(10)=null,
@TOTAL_WORKING_HOURS varchar(10)=null,
@KY_1_7_Minutes varchar(10)=null,
@MORNING_MEETING_5_Minutes varchar(10)=null,
@TEA_BREAK_10_Minutes varchar(10)=null,
@TEA_BREAK_10_Minutes1 varchar(10)=null,
@5S_CLOSING_5_Minutes varchar(10)=null,
@BREAK_TIME_WITHOUT_LUNCH varchar(10)=null,
@FIXED_TIME varchar(10)=null,
@ON_JOB_TRAINING_3_DAYS_NEW_ENTRY_TO_COMPANY varchar(10)=null,
@EXCESS_MP_AFTER_MP_CALCULATION varchar(10)=null,
@OTHER_TRAININGS_BY_HR_TIE_PE_QA_MNT_etc varchar(10)=null,
@MULTISKILLING varchar(10)=null,
@ALL_HANDS_PARASPARA_OTHER_COMPANY_ACTIVITY varchar(10)=null,
@SKILL_COMPETETION_QCC_BUSINESS_TRIP varchar(10)=null,
@INVENTORY varchar(10)=null,
@PLANNED_SPECIAL_5S varchar(10)=null,
@DELAY_ARRIVAL_EARLY_LEAVE_PAYMENT_CUT_LEAVE varchar(10)=null,
@PLANNED_TRIAL_BY_PE varchar(10)=null,
@ENERGY_SHUTDOWN_GOVT_POWER_ONLY varchar(10)=null,
@FIRE_ASSEMBLY_EVACUATION_DRILL varchar(10)=null,
@NPD_TRIALS varchar(10)=null,
@MEDICAL_CHECKUP_OTHER_PLANNED_ACTIVITY_BY_HR varchar(10)=null,
@COMPANY_COST_SAVING_ACTIVITY varchar(10)=null,
@KANBAN_ACHIEVEMENT_EARLY_COMPLETION_FIXED_FOR_THIS_MONTH varchar(10)=null,
@KANBAN_ACHIEVEMENT_EARLY_COMPLETION_BASED_ON_DAYS_CONDITION varchar(10)=null,
@NO_KANBAN_DUE_TO_CUSTOMER_NO_PULL varchar(10)=null,
@PLANNED_ACTIVITY_BY_MAINTENANCE varchar(10)=null,
@PLANNED_ACTIVITY_BY_QA_2ND_QA varchar(10)=null,
@VISITOR_ISO_CUSTOMER_AUDIT_TIME varchar(10)=null,
@MAJOR_PLANNED_CLEAN_UP_BEFORE_LONG_HOLIDAY varchar(10)=null,
@IMPROVEMENT_ACTIVITY_KAIZEN_LAYOUT_CHANGE_etc varchar(10)=null,
@PLANNED_SNACKS_BREAK_AS_PER_HR_POLICY varchar(10)=null,
@5S_BANK_RETURNED_MP varchar(10)=null,
@MULTISKILLING_BANK_RETURNED_MP varchar(10)=null,
@NON_PRESENCE_HRS_DIRECT_EXCLUDE_HOURS varchar(10)=null,
@AVAIABLE_WORKING_DIRECT_HRS varchar(10)=null,
@GOOD_PRODUCTON_HRS varchar(10)=null,
@TOTAL_LOSS_HRS varchar(10)=null,
@PART_REJECTION_SCRAP_REWORK varchar(10)=null,
@LOSS_HRS_RATIO varchar(10)=null,
@AVAIABLE_WORKING_HRS varchar(10)=null,
@GOOD_PRODUCTON_HRS_FOR_DAY varchar(10)=null,
@TOTAL_LOSS_HRS_FOR_DAY varchar(10)=null,
@TOTAL_LOSS_HRS_RATIO varchar(10)=null,
@LINE_IN_CHARGE varchar(10)=null,
@LINE_IN_CHARGE_MAN_HOURS varchar(10)=null,
@USED_AS_MANPOWER varchar(10)=null,
@USED_AS_MANHOUR varchar(10)=null,
@USED_AS_OBSERVER varchar(10)=null,
@USED_AS_OBSERVER_MANHOUR varchar(10)=null,
@KPI varchar(10)=null,
@DIRECT_HRS varchar(10)=null,
@GOOD_HRS varchar(10)=null,
@DPR varchar(10)=null,
@BASE_GH_RATIO varchar(10)=null,
@GH_AGAINST_BASE varchar(10)=null,
@DIRECT_HRS1 varchar(10)=null,
@GOOD_HRS1 varchar(10)=null,
@GH_AGAINST_BASE1 varchar(10)=null,
@DPR1 varchar(10)=null,
@LHR varchar(10)=null,
@LHR_DAILY varchar(10)=null,
@LEND varchar(10)=null,
@BANK varchar(10)=null,
@OJT varchar(10)=null,
@EXCLUDE varchar(10)=null,
@PURE_EXCLUDE varchar(10)=null,
@MIZ_DH varchar(10)=null,
@OUTLINE_DH varchar(10)=null,
@FQA_GH varchar(10)=null,
@INLINE_MP_LENDING_AFTER_MAN_POWER_BANKING varchar(10)=null,
@CreatedBy varchar(100)=null,
@Type varchar(100)=null,
@ShiftName varchar(20) = null,
@FromDate varchar(30)=null,
@ToDate varchar(30)=null,
@NPDDirectHr varchar(20)=null,
@NPDExcludHr varchar(20)=null,
@Result varchar(100)='' output
)
as
begin
if(@Type ='Save')
begin
begin try
--check whether same machine already added
if(exists(select * from [dbo].tbl_KPIEntry where fromdate>=@FromDate and  shiftname =@shiftname AND MachineName=@MachineName AND [MachineGroup]=@MachineGroupName))
begin
rollback transaction
set @Result='MODEL ALREADY EXISTS'
return
end
 insert into tbl_KPIEntry
([MachineGroup],[MachineName],[ModelName],[TOTAL MANPOWER GIVEN BY COMPANY],[ABSENT],[INLINE OPERATOR],[OFFLINE (LINE PARTS FEEDER)],[OUTLINE (LINE SUPPORTER)],[DIRECT MANPOWER]
      ,[SUPERVISOR],[INLINE MANPOWER],[OFFLINE (LINE PARTS FEEDER) MANHOUR],[OUTLINE (LINE SUPPORTER) MANHOUR],[SUPERVISOR_MANHOUR],[INLINE MANPOWER TAKEN FROM BANK],[INLINE BORROWED AFTER MAN POWER BANKING],[OFFLINE(MIZ) MANPOWER TAKEN FROM BANK]
      ,[OFFLINE(MIZ) BORROWED AFTER MAN POWER BANKING],[OUTLINE (SUPPORTER) TAKEN FROM OTHER LINES],[DIRECT MP WORKED IN LINE (TL / GL / SL / QA / LOGISTICS - BELOW AM)]
      ,[INLINE MP GIVEN TO BANK],[OFFLINE(MIZ) GIVEN TO BANK],[OUTLINE (SUPPORTER) LENDING]
      ,[OFFLINE(MIZ) LENDING AFTER MAN POWER BANKING],[INDIRECT WORKED IN LINE (Prod./Logi/QA - above AM & Other dept members)],[SHIFT WORKIG HRS],[LUNCH TIME (30 Minutes)]
      ,[TOTAL WORKING HOURS],[KY ( 1.7 Minutes)],[MORNING MEETING (5 Minutes)],[TEA BREAK (10 Minutes)],[TEA BREAK (10 Minutes)1],[5S & CLOSING (5 Minutes)],[BREAK TIME WITHOUT LUNCH]
      ,[FIXED TIME],[ON JOB TRAINING (3 DAYS-NEW ENTRY TO COMPANY)],[EXCESS MP AFTER MP CALCULATION],[OTHER TRAININGS (BY HR, TIE, PE, QA, MNT etc)],[MULTISKILLING]
      ,[ALL HANDS / PARASPARA / OTHER COMPANY ACTIVITY],[SKILL COMPETETION / QCC / BUSINESS TRIP],[INVENTORY],[PLANNED / SPECIAL 5S],[DELAY ARRIVAL / EARLY LEAVE (PAYMENT CUT/LEAVE)]
      ,[PLANNED TRIAL BY PE],[ENERGY SHUTDOWN (GOVT POWER ONLY)],[FIRE ASSEMBLY / EVACUATION DRILL],[NPD TRIALS],[MEDICAL CHECKUP / OTHER PLANNED ACTIVITY BY HR]
      ,[COMPANY COST SAVING ACTIVITY],[KANBAN ACHIEVEMENT-EARLY COMPLETION (FIXED FOR THIS MONTH)],[KANBAN ACHIEVEMENT-EARLY COMPLETION (BASED ON DAY'S CONDITION)],[NO KANBAN DUE TO CUSTOMER NO PULL]
      ,[PLANNED ACTIVITY BY MAINTENANCE],[PLANNED ACTIVITY BY QA / 2ND QA],[VISITOR / ISO / CUSTOMER AUDIT TIME],[MAJOR / PLANNED CLEAN UP BEFORE LONG HOLIDAY]
      ,[IMPROVEMENT ACTIVITY (KAIZEN/LAYOUT CHANGE etc)],[PLANNED SNACKS BREAK AS PER HR POLICY],[5S (BANK RETURNED MP)],[MULTISKILLING (BANK RETURNED MP)]
      ,[NON PRESENCE HRS - DIRECT (EXCLUDE HOURS)],[AVAIABLE WORKING (DIRECT) HRS],[GOOD PRODUCTON HRS],[TOTAL LOSS HRS],[PART REJECTION (SCRAP+REWORK)],[LOSS HRS RATIO]
      ,[AVAIABLE WORKING HRS],[GOOD PRODUCTON HRS FOR DAY],[TOTAL LOSS HRS FOR DAY],[TOTAL LOSS HRS RATIO],[LINE IN-CHARGE],[LINE IN-CHARGE MAN-HOURS],[USED AS MANPOWER]
      ,[USED AS MANHOUR],[USED AS OBSERVER MANHOUR],[KPI],[DIRECT HRS],[GOOD HRS],[DPR],[BASE GH RATIO],[GH AGAINST BASE],[DIRECT HRS1],[GOOD HRS1],[GH AGAINST BASE1]
      ,[DPR1],[LHR],[LHR DAILY],[LEND],[BANK],[OJT],[EXCLUDE],[PURE EXCLUDE],[MIZ DH],[OUTLINE DH],[FQA GH],[CreatedBy],[CreatedOn],[INLINE MP LENDING AFTER MAN POWER BANKING],Fromdate,ToDate,ShiftName,[USED AS OBSERVER],NPDDirectHr,NPDExcludHr)

 values(@MachineGroupName,@MachineName,@ModelName,@TOTAL_MANPOWER_GIVEN_BY_COMPANY,
@ABSENT  ,
@INLINE_OPERATOR  ,
@OFFLINE_LINE_PARTS_FEEDER  ,
@OUTLINE_LINE_SUPPORTER  ,
@DIRECT_MANPOWER  ,
@SUPERVISOR  ,
@INLINE_MANPOWER  ,
@OFFLINE_LINE_PARTS_FEEDER_MANHOUR  ,
@OUTLINE_LINE_SUPPORTER_MANHOUR  ,
@SUPERVISOR_MANHOUR  ,
@INLINE_MANPOWER_TAKEN_FROM_BANK  ,
@INLINE_BORROWED_AFTER_MAN_POWER_BANKING  ,
@OFFLINE_MIZ_MANPOWER_TAKEN_FROM_BANK  ,
@OFFLINE_MIZ_BORROWED_AFTER_MAN_POWER_BANKING  ,
@OUTLINE_SUPPORTER_TAKEN_FROM_OTHER_LINES  ,
@DIRECT_MP_WORKED_IN_LINE_TL_GL_SL_QA_LOGISTICS_BELOW_AM  ,
@INLINE_MP_GIVEN_TO_BANK  ,
@OFFLINE_MIZ_GIVEN_TO_BANK  ,
@OUTLINE_SUPPORTER_LENDING  ,
@OFFLINE_MIZ_LENDING_AFTER_MAN_POWER_BANKING  ,
@INDIRECT_WORKED_IN_LINE_Prod_Logi_QA_above_AM_Other_dept_members  ,
@SHIFT_WORKIG_HRS  ,
@LUNCH_TIME_30_Minutes  ,
@TOTAL_WORKING_HOURS  ,
@KY_1_7_Minutes  ,
@MORNING_MEETING_5_Minutes  ,
@TEA_BREAK_10_Minutes  ,
@TEA_BREAK_10_Minutes1  ,
@5S_CLOSING_5_Minutes  ,
@BREAK_TIME_WITHOUT_LUNCH  ,
@FIXED_TIME  ,
@ON_JOB_TRAINING_3_DAYS_NEW_ENTRY_TO_COMPANY  ,
@EXCESS_MP_AFTER_MP_CALCULATION  ,
@OTHER_TRAININGS_BY_HR_TIE_PE_QA_MNT_etc  ,
@MULTISKILLING  ,
@ALL_HANDS_PARASPARA_OTHER_COMPANY_ACTIVITY  ,
@SKILL_COMPETETION_QCC_BUSINESS_TRIP  ,
@INVENTORY  ,
@PLANNED_SPECIAL_5S  ,
@DELAY_ARRIVAL_EARLY_LEAVE_PAYMENT_CUT_LEAVE  ,
@PLANNED_TRIAL_BY_PE  ,
@ENERGY_SHUTDOWN_GOVT_POWER_ONLY  ,
@FIRE_ASSEMBLY_EVACUATION_DRILL  ,
@NPD_TRIALS  ,
@MEDICAL_CHECKUP_OTHER_PLANNED_ACTIVITY_BY_HR  ,
@COMPANY_COST_SAVING_ACTIVITY  ,
@KANBAN_ACHIEVEMENT_EARLY_COMPLETION_FIXED_FOR_THIS_MONTH  ,
@KANBAN_ACHIEVEMENT_EARLY_COMPLETION_BASED_ON_DAYS_CONDITION  ,
@NO_KANBAN_DUE_TO_CUSTOMER_NO_PULL  ,
@PLANNED_ACTIVITY_BY_MAINTENANCE  ,
@PLANNED_ACTIVITY_BY_QA_2ND_QA  ,
@VISITOR_ISO_CUSTOMER_AUDIT_TIME  ,
@MAJOR_PLANNED_CLEAN_UP_BEFORE_LONG_HOLIDAY  ,
@IMPROVEMENT_ACTIVITY_KAIZEN_LAYOUT_CHANGE_etc  ,
@PLANNED_SNACKS_BREAK_AS_PER_HR_POLICY  ,
@5S_BANK_RETURNED_MP  ,
@MULTISKILLING_BANK_RETURNED_MP  ,
@NON_PRESENCE_HRS_DIRECT_EXCLUDE_HOURS  ,
@AVAIABLE_WORKING_DIRECT_HRS  ,
@GOOD_PRODUCTON_HRS  ,
@TOTAL_LOSS_HRS  ,
@PART_REJECTION_SCRAP_REWORK  ,
@LOSS_HRS_RATIO  ,
@AVAIABLE_WORKING_HRS  ,
@GOOD_PRODUCTON_HRS_FOR_DAY  ,
@TOTAL_LOSS_HRS_FOR_DAY  ,
@TOTAL_LOSS_HRS_RATIO  ,
@LINE_IN_CHARGE  ,
@LINE_IN_CHARGE_MAN_HOURS  ,
@USED_AS_MANPOWER  ,
@USED_AS_MANHOUR  ,
@USED_AS_OBSERVER_MANHOUR  ,
@KPI  ,
@DIRECT_HRS  ,
@GOOD_HRS  ,
@DPR  ,
@BASE_GH_RATIO  ,
@GH_AGAINST_BASE  ,
@DIRECT_HRS1  ,
@GOOD_HRS1  ,
@GH_AGAINST_BASE1  ,
@DPR1  ,
@LHR  ,
@LHR_DAILY  ,
@LEND  ,
@BANK  ,
@OJT  ,
@EXCLUDE  ,
@PURE_EXCLUDE  ,
@MIZ_DH  ,
@OUTLINE_DH  ,
@FQA_GH  ,
@CreatedBy,getdate(),@INLINE_MP_LENDING_AFTER_MAN_POWER_BANKING,@Fromdate,@ToDate,@ShiftName,@USED_AS_OBSERVER,@NPDDirectHr,@NPDExcludHr)
set @Result='Saved'
end try
begin catch
set @Result=ERROR_MESSAGE()
end catch
end

if(@Type ='Update')
begin
begin try
Update tbl_KPIEntry set
[TOTAL MANPOWER GIVEN BY COMPANY]=@TOTAL_MANPOWER_GIVEN_BY_COMPANY,
[ABSENT]=@ABSENT,[INLINE OPERATOR]=@INLINE_OPERATOR
,[OFFLINE (LINE PARTS FEEDER)]=@OFFLINE_LINE_PARTS_FEEDER
,[OUTLINE (LINE SUPPORTER)]=@OUTLINE_LINE_SUPPORTER
,[DIRECT MANPOWER]=@DIRECT_MANPOWER
      ,[SUPERVISOR]=@SUPERVISOR
 ,[INLINE MANPOWER]=@INLINE_MANPOWER,
 [OFFLINE (LINE PARTS FEEDER) MANHOUR]=@OFFLINE_LINE_PARTS_FEEDER_MANHOUR
 ,[OUTLINE (LINE SUPPORTER) MANHOUR]=@OUTLINE_LINE_SUPPORTER_MANHOUR,
 [SUPERVISOR_MANHOUR]=@SUPERVISOR_MANHOUR,
 [INLINE MANPOWER TAKEN FROM BANK]=@INLINE_MANPOWER_TAKEN_FROM_BANK
 ,[INLINE BORROWED AFTER MAN POWER BANKING]=@INLINE_BORROWED_AFTER_MAN_POWER_BANKING
 ,[OFFLINE(MIZ) MANPOWER TAKEN FROM BANK]=@OFFLINE_MIZ_MANPOWER_TAKEN_FROM_BANK
      ,[OFFLINE(MIZ) BORROWED AFTER MAN POWER BANKING]=@OFFLINE_MIZ_BORROWED_AFTER_MAN_POWER_BANKING,
 [OUTLINE (SUPPORTER) TAKEN FROM OTHER LINES]=@OUTLINE_SUPPORTER_TAKEN_FROM_OTHER_LINES
 ,[DIRECT MP WORKED IN LINE (TL / GL / SL / QA / LOGISTICS - BELOW AM)]=@DIRECT_MP_WORKED_IN_LINE_TL_GL_SL_QA_LOGISTICS_BELOW_AM
      ,[INLINE MP GIVEN TO BANK]=@INLINE_MP_GIVEN_TO_BANK
 ,[OFFLINE(MIZ) GIVEN TO BANK]=@OFFLINE_MIZ_GIVEN_TO_BANK,
 [OUTLINE (SUPPORTER) LENDING]=@OUTLINE_SUPPORTER_LENDING
      ,[OFFLINE(MIZ) LENDING AFTER MAN POWER BANKING]=@OFFLINE_MIZ_LENDING_AFTER_MAN_POWER_BANKING
 ,[INDIRECT WORKED IN LINE (Prod./Logi/QA - above AM & Other dept members)]=@INDIRECT_WORKED_IN_LINE_Prod_Logi_QA_above_AM_Other_dept_members
 ,[SHIFT WORKIG HRS]=@SHIFT_WORKIG_HRS,
 [LUNCH TIME (30 Minutes)]=@LUNCH_TIME_30_Minutes
 --need to update
      ,[TOTAL WORKING HOURS]=@TOTAL_WORKING_HOURS
 ,[KY ( 1.7 Minutes)]=@KY_1_7_Minutes,
 [MORNING MEETING (5 Minutes)]=@MORNING_MEETING_5_Minutes,
 [TEA BREAK (10 Minutes)]=@TEA_BREAK_10_Minutes
 ,[TEA BREAK (10 Minutes)1]=@TEA_BREAK_10_Minutes1
 ,[5S & CLOSING (5 Minutes)]=@5S_CLOSING_5_Minutes
 ,[BREAK TIME WITHOUT LUNCH]=@BREAK_TIME_WITHOUT_LUNCH
      ,[FIXED TIME]=@FIXED_TIME
 ,[ON JOB TRAINING (3 DAYS-NEW ENTRY TO COMPANY)]=@ON_JOB_TRAINING_3_DAYS_NEW_ENTRY_TO_COMPANY
 ,[EXCESS MP AFTER MP CALCULATION]=@EXCESS_MP_AFTER_MP_CALCULATION
 ,[OTHER TRAININGS (BY HR, TIE, PE, QA, MNT etc)]=@OTHER_TRAININGS_BY_HR_TIE_PE_QA_MNT_etc,[MULTISKILLING]=@MULTISKILLING
      ,[ALL HANDS / PARASPARA / OTHER COMPANY ACTIVITY]=@ALL_HANDS_PARASPARA_OTHER_COMPANY_ACTIVITY
 ,[SKILL COMPETETION / QCC / BUSINESS TRIP]=@SKILL_COMPETETION_QCC_BUSINESS_TRIP
 ,[INVENTORY]=@INVENTORY,
 [PLANNED / SPECIAL 5S]=@PLANNED_SPECIAL_5S,
 [DELAY ARRIVAL / EARLY LEAVE (PAYMENT CUT/LEAVE)]=@DELAY_ARRIVAL_EARLY_LEAVE_PAYMENT_CUT_LEAVE
      ,[PLANNED TRIAL BY PE]=@PLANNED_TRIAL_BY_PE
 ,[ENERGY SHUTDOWN (GOVT POWER ONLY)]=@ENERGY_SHUTDOWN_GOVT_POWER_ONLY,
 [FIRE ASSEMBLY / EVACUATION DRILL]=@FIRE_ASSEMBLY_EVACUATION_DRILL,
 [NPD TRIALS]=@NPD_TRIALS,
 [MEDICAL CHECKUP / OTHER PLANNED ACTIVITY BY HR]=@MEDICAL_CHECKUP_OTHER_PLANNED_ACTIVITY_BY_HR
      ,[COMPANY COST SAVING ACTIVITY]=@COMPANY_COST_SAVING_ACTIVITY,
-- [KANBAN ACHIEVEMENT-EARLY COMPLETION (FIXED FOR THIS MONTH)]=@KANBAN_ACHIEVEMENT_EARLY_COMPLETION_FIXED_FOR_THIS_MONTH,
-- [KANBAN ACHIEVEMENT-EARLY COMPLETION (BASED ON DAY'S CONDITION)=@KANBAN_ACHIEVEMENT_EARLY_COMPLETION_BASED_ON_DAYS_CONDITION,
 [NO KANBAN DUE TO CUSTOMER NO PULL]=@NO_KANBAN_DUE_TO_CUSTOMER_NO_PULL
      ,[PLANNED ACTIVITY BY MAINTENANCE]=@PLANNED_ACTIVITY_BY_MAINTENANCE,
 [PLANNED ACTIVITY BY QA / 2ND QA]=@PLANNED_ACTIVITY_BY_QA_2ND_QA,
 [VISITOR / ISO / CUSTOMER AUDIT TIME]=@VISITOR_ISO_CUSTOMER_AUDIT_TIME
 ,[MAJOR / PLANNED CLEAN UP BEFORE LONG HOLIDAY]=@MAJOR_PLANNED_CLEAN_UP_BEFORE_LONG_HOLIDAY
      ,[IMPROVEMENT ACTIVITY (KAIZEN/LAYOUT CHANGE etc)]=@IMPROVEMENT_ACTIVITY_KAIZEN_LAYOUT_CHANGE_etc
 ,[PLANNED SNACKS BREAK AS PER HR POLICY]=@PLANNED_SNACKS_BREAK_AS_PER_HR_POLICY,
 [5S (BANK RETURNED MP)]=@5S_BANK_RETURNED_MP,
 [MULTISKILLING (BANK RETURNED MP)]=@MULTISKILLING_BANK_RETURNED_MP
      ,[NON PRESENCE HRS - DIRECT (EXCLUDE HOURS)]=@NON_PRESENCE_HRS_DIRECT_EXCLUDE_HOURS,
 [AVAIABLE WORKING (DIRECT) HRS]=@AVAIABLE_WORKING_DIRECT_HRS,
 [GOOD PRODUCTON HRS]=@GOOD_PRODUCTON_HRS,
 [TOTAL LOSS HRS]=@TOTAL_LOSS_HRS,
 [PART REJECTION (SCRAP+REWORK)]=@PART_REJECTION_SCRAP_REWORK,
 [LOSS HRS RATIO]=@LOSS_HRS_RATIO
      ,[AVAIABLE WORKING HRS]=@AVAIABLE_WORKING_HRS,
 [GOOD PRODUCTON HRS FOR DAY]=@GOOD_PRODUCTON_HRS_FOR_DAY,
 [TOTAL LOSS HRS FOR DAY]=@TOTAL_LOSS_HRS_FOR_DAY,
 [TOTAL LOSS HRS RATIO]=@TOTAL_LOSS_HRS_RATIO,
 [LINE IN-CHARGE]=@LINE_IN_CHARGE,
 [LINE IN-CHARGE MAN-HOURS]=@LINE_IN_CHARGE_MAN_HOURS,
 [USED AS MANPOWER]=@USED_AS_MANPOWER
      ,[USED AS MANHOUR]=@USED_AS_MANHOUR,
 [USED AS OBSERVER MANHOUR]=@USED_AS_OBSERVER_MANHOUR
 ,[KPI]=@KPI,
 [DIRECT HRS]=@DIRECT_HRS
 ,[GOOD HRS]=@GOOD_HRS,
 [DPR]=@DPR,
 [BASE GH RATIO]=@BASE_GH_RATIO,
 [GH AGAINST BASE]=@GH_AGAINST_BASE
 ,[DIRECT HRS1]=@DIRECT_HRS1,
 [GOOD HRS1]=@GOOD_HRS1,
 [GH AGAINST BASE1]=@GH_AGAINST_BASE1
      ,[DPR1]=@DPR1,[LHR]=@LHR,[LHR DAILY]=@LHR_DAILY,[LEND]=@LEND
 ,[BANK]=@BANK,[OJT]=@OJT,[EXCLUDE]=@EXCLUDE,[PURE EXCLUDE]=@PURE_EXCLUDE
 ,[MIZ DH]=@MIZ_DH,[OUTLINE DH]=@OUTLINE_DH,[FQA GH]=@FQA_GH
 ,[INLINE MP LENDING AFTER MAN POWER BANKING]=@INLINE_MP_LENDING_AFTER_MAN_POWER_BANKING,
 Fromdate=@Fromdate,ToDate=@ToDate,ShiftName= @ShiftName,[USED AS OBSERVER]=@USED_AS_OBSERVER,NPDDirectHr=@NPDDirectHr,NPDExcludHr=@NPDExcludHr
 where RefNo=@Slno
set @Result='Updated'
end try
begin catch
set @Result=ERROR_MESSAGE()
end catch
end

if(@Type ='Delete')
begin
begin try
delete  from tbl_KPIEntry where  RefNo=@Slno
set @Result='Deleted'
end try
begin catch
set @Result=ERROR_MESSAGE()
end catch
end
if(@Type ='LoadDetails')
begin
begin try
Select RefNo as 'RefNo', row_number() over(order by (select 1))  as 'SLNO',[TOTAL MANPOWER GIVEN BY COMPANY],[ABSENT],[INLINE OPERATOR],[OFFLINE (LINE PARTS FEEDER)]
,[OUTLINE (LINE SUPPORTER)],[DIRECT MANPOWER]
      ,[SUPERVISOR],[INLINE MANPOWER],[OFFLINE (LINE PARTS FEEDER) MANHOUR],[OUTLINE (LINE SUPPORTER) MANHOUR],[SUPERVISOR_MANHOUR],[INLINE MANPOWER TAKEN FROM BANK],[INLINE BORROWED AFTER MAN POWER BANKING],[OFFLINE(MIZ) MANPOWER TAKEN FROM BANK]
      ,[OFFLINE(MIZ) BORROWED AFTER MAN POWER BANKING],[OUTLINE (SUPPORTER) TAKEN FROM OTHER LINES],[DIRECT MP WORKED IN LINE (TL / GL / SL / QA / LOGISTICS - BELOW AM)]
      ,[INLINE MP GIVEN TO BANK],[OFFLINE(MIZ) GIVEN TO BANK],[OUTLINE (SUPPORTER) LENDING]
      ,[OFFLINE(MIZ) LENDING AFTER MAN POWER BANKING],[INDIRECT WORKED IN LINE (Prod./Logi/QA - above AM & Other dept members)]'INDIRECTWORKEDINLINE',[SHIFT WORKIG HRS],[LUNCH TIME (30 Minutes)]
 --need to update
      ,[TOTAL WORKING HOURS],[KY ( 1.7 Minutes)]'KY17Minutes',[MORNING MEETING (5 Minutes)],[TEA BREAK (10 Minutes)],[TEA BREAK (10 Minutes)1],[5S & CLOSING (5 Minutes)]'[5S CLOSING 5 Minutes]',[BREAK TIME WITHOUT LUNCH]
      ,[FIXED TIME],[ON JOB TRAINING (3 DAYS-NEW ENTRY TO COMPANY)],[EXCESS MP AFTER MP CALCULATION],[OTHER TRAININGS (BY HR, TIE, PE, QA, MNT etc)]'[OTHER TRAININGS BY HR TIE PE QA MNT etc]',[MULTISKILLING]
      ,[ALL HANDS / PARASPARA / OTHER COMPANY ACTIVITY],[SKILL COMPETETION / QCC / BUSINESS TRIP],[INVENTORY],[PLANNED / SPECIAL 5S],[DELAY ARRIVAL / EARLY LEAVE (PAYMENT CUT/LEAVE)]
      ,[PLANNED TRIAL BY PE],[ENERGY SHUTDOWN (GOVT POWER ONLY)],[FIRE ASSEMBLY / EVACUATION DRILL],[NPD TRIALS],[MEDICAL CHECKUP / OTHER PLANNED ACTIVITY BY HR]
      ,[COMPANY COST SAVING ACTIVITY],[KANBAN ACHIEVEMENT-EARLY COMPLETION (FIXED FOR THIS MONTH)],[KANBAN ACHIEVEMENT-EARLY COMPLETION (BASED ON DAY'S CONDITION)]'[KANBAN ACHIEVEMENT-EARLY COMPLETION BASED ON DAYS CONDITION]',[NO KANBAN DUE TO CUSTOMER NO PULL]
      ,[PLANNED ACTIVITY BY MAINTENANCE],[PLANNED ACTIVITY BY QA / 2ND QA],[VISITOR / ISO / CUSTOMER AUDIT TIME],[MAJOR / PLANNED CLEAN UP BEFORE LONG HOLIDAY]
      ,[IMPROVEMENT ACTIVITY (KAIZEN/LAYOUT CHANGE etc)],[PLANNED SNACKS BREAK AS PER HR POLICY],[5S (BANK RETURNED MP)],[MULTISKILLING (BANK RETURNED MP)]
      ,[NON PRESENCE HRS - DIRECT (EXCLUDE HOURS)],[AVAIABLE WORKING (DIRECT) HRS],[GOOD PRODUCTON HRS],[TOTAL LOSS HRS],[PART REJECTION (SCRAP+REWORK)],[LOSS HRS RATIO]
      ,[AVAIABLE WORKING HRS],[GOOD PRODUCTON HRS FOR DAY],[TOTAL LOSS HRS FOR DAY],[TOTAL LOSS HRS RATIO],[LINE IN-CHARGE],[LINE IN-CHARGE MAN-HOURS],[USED AS MANPOWER]
      ,[USED AS MANHOUR],[USED AS OBSERVER MANHOUR],[KPI],[DIRECT HRS],[GOOD HRS],[DPR],[BASE GH RATIO],[GH AGAINST BASE],[DIRECT HRS1],[GOOD HRS1],[GH AGAINST BASE1]
      ,[DPR1],[LHR],[LHR DAILY],[LEND],[BANK],[OJT],[EXCLUDE],[PURE EXCLUDE],[MIZ DH],[OUTLINE DH],[FQA GH],[INLINE MP LENDING AFTER MAN POWER BANKING]
 ,Fromdate,ToDate,ShiftName,[USED AS OBSERVER],NPDDirectHr,NPDExcludHr
 from  [dbo].[tbl_KPIEntry]
  WHERE MachineGroup=@MachineGroupName and MachineName=@MachineName and convert(date, createdon) =convert(date,getdate()) order by Slno
end try
begin catch
select ERROR_MESSAGE() as 'Error'
end catch
end
if(@Type ='LoadModelDetails')
begin
begin try
-- DECLARE @MinuteDiff VARCHAR(20),@ProductionPlan VARCHAR(20),@TotalQty int,@TotalPlan int=0,@date datetime,@CycleTime varchar(20),@HourPlan varchar(20)='0',@HourQty varchar(20)='0',@Time varchar(50)=null,
--@Break varchar(20),@TimeWorking varchar(100),@ChangeOver1 varchar(20)

--exec Proc_GetShiftandTimeDetails @MachineGroupName,@MachineName,@ShiftName output,@Time output,@date output,@Break output,@ChangeOver1 output,@TimeWorking output

select ManPower from tbl_ManPower where ShiftName =@ShiftName and MachineGroup=@MachineGroupName and MachineName=@MachineName and createdon between @fromdate and @todate
select row_number() over(order by (select 1))  as 'SLNO',(select PartNo   from tbl_ModuleMaster where ModelName= or1.ModelName) as 'PartNo',(select BaseStandardTime from tbl_ModuleMaster where ModelName= or1.ModelName) as 'BaseTime', (select PresentStandardtTime from tbl_ModuleMaster where ModelName= or1.ModelName) as 'STDTime', ModelName,sum(convert(int,hourqty)) as  'OKQty',0 as 'RejQty',CyscleTime
 from tbl_ORMonitoring_1 as or1 where Shiftname=@ShiftName and MachineGroup=@MachineGroupName and MachineName=@MachineName
 and CraetedOn between @fromdate and @todate group by ModelName,CyscleTime
select convert(decimal(2,2),(convert(decimal,1.7)/60)) as ky,
convert(decimal(2,2),(convert(decimal,(datediff(minute,substring(Break1,0,6),substring(Break1,6,6))))/60)) as MorningMeet,
convert(decimal(2,2),(convert(decimal,(datediff(minute,substring(Break2,0,6),substring(Break2,6,6))))/60)) as Teabreak1
,convert(decimal(2,2),(convert(decimal,(datediff(minute,substring(Break3,0,6),substring(Break3,6,6))))/60)) as Lunch
,convert(decimal(2,2),(convert(decimal,(datediff(minute,substring(Break4,0,6),substring(Break4,6,6))))/60)) as Teabreak2
,convert(decimal(2,2),(convert(decimal,(datediff(minute,substring(Break5,0,6),substring(Break5,6,6))))/60)) as CloseMeet
,ShiftTiming,ShiftName,[LossSeconds],TotalWorkingHour from tbl_ShiftMaster as or1
where Shiftname=@ShiftName and MachineGrName=@MachineGroupName and MachineName=@MachineName

select BaseGHRatio from tbl_MachineGroup where MachineGrName=@MachineGroupName and MachineName=@MachineName
end try
begin catch
set @Result=ERROR_MESSAGE()
end catch
end

end

GO
ALTER PROC [dbo].[Proc_MachineGroupMaster]
(
@MachineGrID INT=null,
@MachineGroupName varchar(100)=null,
@MachineName varchar(100)=null,
@Operation varchar(100)=null,
@BaseGhRatio varchar(50)=null,
@Status varchar(100)=null,
@CreatedBy varchar(100)=null,
@Type varchar(100)=null,
@Section varchar(20)=null,
@Result varchar(100)='' output
)
as
if(@Type ='Save')
begin
begin try
begin transaction
--check whether same machine already added
if(exists(select * from dbo.tbl_MachineGroup where MachineGrID=@MachineGrID and MachineName=@MachineName and Operation=@Operation))
begin
rollback transaction
set @Result='LINE ALREADY EXISTS'
return
end

insert into [dbo].[tbl_MachineGroup](MachineGrName,MachineName,Status,CreatedBy,CreatedOn,Operation,BaseGHRatio,Section)values
(@MachineGroupName,@MachineName,@Status,@CreatedBy,GETDATE(),@Operation,@BaseGhRatio,@Section)
set @Result='Saved'
commit transaction
end try 
begin catch
rollback transaction
set @Result=ERROR_MESSAGE()
end catch
end
if(@Type ='Update')
begin
begin try
begin transaction
--if(exists(select * from tbl_UserMaster where UserID=@UserID))
--begin
--rollback transaction
--set @Result='USER ID ALREADY EXISTS'
--return
--end
update  [dbo].[tbl_MachineGroup] set Section=@Section, MachineGrName=@MachineGroupName,MachineName=@MachineName,Status=@Status,[ModifiedBy] =@CreatedBy,[Modifiedon]=getdate(),Operation=@Operation,BaseGHRatio=@BaseGhRatio where MachineGrID=@MachineGrID 
set @Result='Updated'
commit transaction
end try 
begin catch
rollback transaction
set @Result=ERROR_MESSAGE()
end catch
end
if(@Type ='Delete')
begin
begin try
begin transaction
delete  [dbo].[tbl_MachineGroup] where  MachineGrID=@MachineGrID
set @Result='Deleted'
commit transaction
end try 
begin catch
rollback transaction
set @Result=ERROR_MESSAGE()
end catch
end
if(@Type ='LoadDetails')
begin
begin try
Select row_number() over(order by (select 1))  as 'refno',MachineGrID'SLNO',MachineGrName,MachineName,Operation,BaseGhRatio,Status,Section from  [dbo].[tbl_MachineGroup] order by MachineGrID,Operation
end try 
begin catch
select ERROR_MESSAGE() as 'Error'
end catch
end
if(@Type ='GetMachineGroupID')
begin
begin try
Select DISTINCT MachineGrName from  [dbo].[tbl_MachineGroup]
end try 
begin catch
select ERROR_MESSAGE() as 'Error'
end catch
end
if(@Type ='GetMachineGroupname')
begin
begin try
Select DISTINCT MachineGrName from  [dbo].[tbl_MachineGroup]
end try 
begin catch
select ERROR_MESSAGE() as 'Error'
end catch
end
if(@Type ='GetMachinename')
begin
begin try
Select DISTINCT MachineName from  [dbo].[tbl_MachineGroup] where MachineGrName=@MachineGroupName
end try 
begin catch
select ERROR_MESSAGE() as 'Error'
end catch
end
if(@Type ='GetOperation')
begin
begin try
Select DISTINCT [Operation],'False' as Flag from  [dbo].[tbl_MachineGroup] where MachineName=@MachineName and MachineGrName=@MachineGroupName ORDER BY [Operation]
end try 
begin catch
select ERROR_MESSAGE() as 'Error'
end catch
end
if(@Type ='GetMachineGroupnameForHHT')
begin
begin try
Select MachineGrName, MachineName,ModelName from tbl_ModuleMaster
end try 
begin catch
select ERROR_MESSAGE() as 'Error'
end catch
end


GO
--[Proc_Reports] 'sfa ii','SFA II FRONT','''first shift''','20 apr 2021 06:30:00','20 apr 2021 15:00:00','OperationRatio','''SFA II HEATER CORE''',''
ALTER proc [dbo].[Proc_Reports]
(
@MachineGroupName varchar(50)=null,
@MachineName varchar(max)=null,
@ShiftName varchar(50)=null,
@Fromdate varchar(50)=null,
@Todate varchar(50)=null,
@Type varchar(50)=null,
@ModelNo varchar(500)=null,
@Station varchar(500)=null,
@MachineTime varchar(100)=null,
@ReportType varchar(20)=null,
@Month varchar(20)=null,
@KPIHeaderType varchar(100)=null
)	
as
begin try 
if(@Type='OperationRatio')
begin

--exec ('Select [Time],ModelName as ModelNo,
--(select convert(int,ISNULL(SUM(convert(decimal(5,1),hp.HourPQty)),0)) from tbl_HourPlan_TotalPlan_1 as HP where  convert(date,hp.createdon)  = convert(date,orm.CraetedOn) 
--and  HP.ModelNo=orm.ModelName and hp.HourTime=orm.time and hp.ShiftName=orm.ShiftName
-- and hp.MachineGroup=orm.MachineGroup and hp.MachineName=orm.MachineName)as TotalProductionPlan,
-- convert(int,ISNULL(SUM(convert(decimal(5,1),HourQty)),0)) as TotalActualPlan,orm.Shiftname,orm.[CyscleTime]+'' S'' as CycleTime,
--convert(varchar(20),  convert(decimal(10,1),(convert(decimal,(convert(int,ISNULL(SUM(convert(decimal(5,1),orm.HourQty)),0))))/
-- (select convert(decimal, convert(int,ISNULL(SUM(convert(decimal(5,1),hp.HourPQty)),1))) from tbl_HourPlan_TotalPlan_1 as HP where  convert(date,hp.createdon)  = convert(date,CraetedOn) 
--and  HP.ModelNo=ModelName and hp.HourTime=orm.time and hp.ShiftName=orm.ShiftName
-- and hp.MachineGroup=MachineGroup and hp.MachineName=MachineName)*100)))+''%'' as HourPers,''Line Group : ''+MachineGroup as LineGroup,''Line Name : ''+MachineName as LineName,''From '+@Fromdate+' To '+@Todate+''' as ''Date'',convert(varchar(20),convert(date, CraetedOn),106) as ''createdon''
--  from [dbo].[tbl_ORMonitoring_1] as orm where
-- ModelName in ('+@ModelNo+') and  shiftname in ('+@ShiftName+') and [MachineGroup]='''+@MachineGroupName+''' and [MachineName]='''+@MachineName+''' and 
--CraetedOn between '''+@Fromdate+''' and '''+@Todate+'''  group by [Time],ModelName,Shiftname,CyscleTime,MachineGroup,MachineName,convert(date, CraetedOn) order by convert(date, CraetedOn)')--xxx group by [Time],ModelName,Shiftname,CyscleTime)
exec ('SELECT  * INTO #tbl_ORMonitoring_1 FROM  tbl_ORMonitoring_1 where ModelName in ('+@ModelNo+') and  shiftname  in ('+@ShiftName+')  and [MachineGroup]='''+@MachineGroupName+''' and [MachineName]='''+@MachineName+''' and 
CraetedOn between '''+@Fromdate+''' and '''+@Todate+'''
 SELECT  * INTO #tbl_HourPlan_TotalPlan_1 FROM  tbl_HourPlan_TotalPlan_1 where ModelNo in ('+@ModelNo+') and  shiftname  in ('+@ShiftName+')  and [MachineGroup]='''+@MachineGroupName+''' and [MachineName]='''+@MachineName+''' and 
createdon between '''+@Fromdate+''' and '''+@Todate+'''
Select HourTime as Time,ModelNo,
convert(int,ISNULL(SUM(convert(decimal(5,1),orm.HourPQty)),0)) as TotalProductionPlan,
 (select convert(int,ISNULL(SUM(convert(decimal(5,1),HourQty)),0))
from #tbl_ORMonitoring_1 or1 where  or1.shiftStartDate  = orm.shiftStartDate  and or1.ModelName=orm.ModelNo and or1.Time=orm.HourTime and or1.Shiftname=orm.Shiftname and or1.[MachineGroup]=Orm.[MachineGroup]
and or1.[MachineName]=orm.[MachineName])as  TotalActualPlan,orm.Shiftname,orm.[CycleTime1]+'' S'' as CycleTime,
convert(varchar(20),convert(decimal(5,1),((select ISNULL(SUM(convert(decimal(5,1),HourQty)),0)
from #tbl_ORMonitoring_1 or1 where  or1.shiftStartDate  = orm.shiftStartDate and or1.ModelName=orm.ModelNo and or1.Time=orm.HourTime and or1.Shiftname=orm.Shiftname and or1.[MachineGroup]=Orm.[MachineGroup]
and or1.[MachineName]=orm.[MachineName])/
ISNULL(SUM(convert(decimal(5,1),orm.HourPQty)),0)*100)))+''%'' as HourPers,
''Line Group : ''+MachineGroup as ''LineGroup'',''Line Name : ''+MachineName as LineName,''From '+@Fromdate+' To '+@Todate+'''  as ''Date'',
convert(varchar(20),convert(date,orm.shiftStartDate),106) as  createdon
  from [dbo].#tbl_HourPlan_TotalPlan_1 as orm where
   ModelNo in ('+@ModelNo+') and shiftname  in ('+@ShiftName+')  and [MachineGroup]='''+@MachineGroupName+''' and [MachineName]='''+@MachineName+''' and 
createdon between '''+@Fromdate+''' and '''+@Todate+''' group by shiftStartDate,  HourTime,ModelNo,Shiftname,CycleTime1,MachineGroup,MachineName,convert(date,orm.createdon) order by  convert(date,orm.createdon),HourTime')
	
end
if(@Type='Dekidaka')
begin
-- Select [Time],
--(select convert(int,ISNULL(SUM(convert(decimal(5,1),hp.HourPQty)),0)) from tbl_HourPlan_TotalPlan_1 as HP where  convert(date,hp.createdon)  = convert(date,orm.CraetedOn) 
--and  HP.ModelNo=orm.ModelName and hp.HourTime=orm.time and hp.ShiftName=orm.ShiftName
-- and hp.MachineGroup=orm.MachineGroup and hp.MachineName=orm.MachineName)as ProductionQty,
-- convert(int,ISNULL(SUM(convert(decimal(5,1),HourQty)),0)) as ActualQty,
-- orm.Shiftname,
--convert(varchar(20),  convert(decimal(10,1),(convert(decimal,(convert(int,ISNULL(SUM(convert(decimal(5,1),orm.HourQty)),0))))/
-- (select convert(decimal, convert(int,ISNULL(SUM(convert(decimal(5,1),hp.HourPQty)),1))) from tbl_HourPlan_TotalPlan_1 as HP where  convert(date,hp.createdon)  = convert(date,CraetedOn) 
--and  HP.ModelNo=ModelName and hp.HourTime=orm.time and hp.ShiftName=orm.ShiftName
-- and hp.MachineGroup=MachineGroup and hp.MachineName=MachineName)*100)))+'%' as HourPers,
--'Line Group : '+MachineGroup as 'LineGroup','Line Name : '+MachineName as 'LineName','From '+@Fromdate+' To '+@Todate  as 'Date',convert(varchar(20),convert(date, CraetedOn),106) as 'createdon','0' as PlanCumulative,'0' as ActualCumulative
--  from [dbo].[tbl_ORMonitoring_1] as orm where
--   shiftname = @ShiftName  and [MachineGroup]=@MachineGroupName and [MachineName]=@MachineName and 
--CraetedOn between @Fromdate and @Todate group by [Time],ModelName,Shiftname,CyscleTime,MachineGroup,MachineName,convert(date,orm.CraetedOn) order by convert(date,orm.CraetedOn) select ModelName,CycleTime,convert(decimal(5,1), (convert(decimal(5,1),CycleTime)/90)*100) as 'Cycletime1' from [dbo].[tbl_ModuleMaster] where [MachineGrName]=@MachineGroupName and [MachineName]=@MachineName--xxx group by [Time],ModelName,Shiftname,CyscleTime,MachineGroup,MachineName

--if(@ShiftName != 'Third shift')
--begin

SELECT  * 
  INTO #tbl_ORMonitoring_1
  FROM  tbl_ORMonitoring_1 where shiftname = @ShiftName  and [MachineGroup]=@MachineGroupName and [MachineName]=@MachineName and 
CraetedOn between @Fromdate and @Todate

--select * from #tbl_ORMonitoring_1

 SELECT  * 
  INTO #tbl_HourPlan_TotalPlan_1
  FROM  tbl_HourPlan_TotalPlan_1 where shiftname = @ShiftName  and [MachineGroup]=@MachineGroupName and [MachineName]=@MachineName and 
createdon between @Fromdate and @Todate

SELECT  * 
  INTO #tbl_CycleTimeCalc_1
  FROM  tbl_CycleTimeCalc_1 where shiftname = @ShiftName  and [MachineGroup]=@MachineGroupName and [MachineName]=@MachineName and 
CreatedDate between @Fromdate and @Todate



 Select HourTime,convert(int,ISNULL(SUM(convert(decimal(5,1),orm.HourPQty1)),0)) as ProductionQty1,
convert(int,ISNULL(SUM(convert(decimal(5,1),orm.HourPQty)),0)) as ProductionQty,
 (select convert(int,ISNULL(SUM(convert(decimal(5,1),HourQty)),0))
from #tbl_ORMonitoring_1 or1 where or1.shiftStartDate  = orm.shiftStartDate  and or1.Time=orm.HourTime and or1.Shiftname=orm.Shiftname and or1.[MachineGroup]=Orm.[MachineGroup]
and or1.[MachineName]=orm.[MachineName])as  ActualQty,
 orm.Shiftname,
convert(varchar(20),convert(decimal(5,1),((select ISNULL(SUM(convert(decimal(5,1),HourQty)),0)
from #tbl_ORMonitoring_1 or1 where or1.shiftStartDate  = orm.shiftStartDate  and or1.Time=orm.HourTime and or1.Shiftname=orm.Shiftname and or1.[MachineGroup]=Orm.[MachineGroup]
and or1.[MachineName]=orm.[MachineName])/
ISNULL(SUM(convert(decimal(5,1),orm.HourPQty)),0)*100))) as HourPers,
'Line Group : '+MachineGroup as 'LineGroup','Line Name : '+MachineName as 'LineName','From '+@Fromdate+' To '+@Todate  as 'Date',
--case when (HourTime !='23:30') and ShiftName='third shift' then convert(varchar(20), dateadd(day,-1,convert(date,createdon)),106) else convert(varchar(20), convert(date,createdon),106) end
convert(varchar(20),convert(date,orm.shiftStartDate),106) as  createdon,
--convert(varchar(20),convert(date, createdon),106) as 'createdon',
'0' as PlanCumulative,'0' as PlanCumulative1,'0' as ActualCumulative
  from [dbo].#tbl_HourPlan_TotalPlan_1 as orm where
   shiftname = @ShiftName  and [MachineGroup]=@MachineGroupName and [MachineName]=@MachineName and 
createdon between @Fromdate and @Todate group by shiftStartDate,  HourTime,Shiftname,MachineGroup,MachineName,convert(date,orm.createdon) order by  convert(date,orm.createdon),HourTime
--	end
	
--if(@ShiftName = 'Third shift')
--begin
-- Select HourTime,convert(int,ISNULL(SUM(convert(decimal(5,1),orm.HourPQty1)),0)) as ProductionQty1,
--convert(int,ISNULL(SUM(convert(decimal(5,1),orm.HourPQty)),0)) as ProductionQty,
-- (select convert(int,ISNULL(SUM(convert(decimal(5,1),HourQty)),0))
--from tbl_ORMonitoring_1 or1 where convert(date,or1.CraetedOn)  >= convert(date,Orm.createdon)  and convert(date,or1.CraetedOn-1)  <= convert(date,Orm.createdon) and or1.Time=orm.HourTime and or1.Shiftname=orm.Shiftname and or1.[MachineGroup]=Orm.[MachineGroup]
--and or1.[MachineName]=orm.[MachineName])as  ActualQty,
-- orm.Shiftname,
--convert(varchar(20),convert(decimal(5,1),((select ISNULL(SUM(convert(decimal(5,1),HourQty)),0)
--from tbl_ORMonitoring_1 or1 where convert(date,or1.CraetedOn)  >= convert(date,Orm.createdon)  and convert(date,or1.CraetedOn-1)  <= convert(date,Orm.createdon)  and or1.Time=orm.HourTime and or1.Shiftname=orm.Shiftname and or1.[MachineGroup]=Orm.[MachineGroup]
--and or1.[MachineName]=orm.[MachineName])/
--ISNULL(SUM(convert(decimal(5,1),orm.HourPQty)),0)*100))) as HourPers,
--'Line Group : '+MachineGroup as 'LineGroup','Line Name : '+MachineName as 'LineName','From '+@Fromdate+' To '+@Todate  as 'Date',
--case when (HourTime !='23:30') and ShiftName='third shift' then convert(varchar(20), dateadd(day,-1,convert(date,createdon)),106) else convert(varchar(20), convert(date,createdon),106) end
--as  createdon,
----convert(varchar(20),convert(date, createdon),106) as 'createdon',
--'0' as PlanCumulative,'0' as PlanCumulative1,'0' as ActualCumulative
--  from [dbo].tbl_HourPlan_TotalPlan_1 as orm where
--   shiftname = @ShiftName  and [MachineGroup]=@MachineGroupName and [MachineName]=@MachineName and 
--createdon between @Fromdate and @Todate group by   HourTime,Shiftname,MachineGroup,MachineName,convert(date,orm.createdon) order by  convert(date,orm.createdon),HourTime
--	end
create  table #Temp1
(
Time varchar(50),
ModelName varchar(20),
CycleTime varchar(50),
CycleTime1 varchar(20),
PlanCount varchar(20),
PlanCumulative varchar(20),
AlphaCode varchar(20)
)
declare @i int=1,@count int,@fromTime varchar(20),@ToTime varchar(20),@CycleTime varchar(20),@CycleTime1 varchar(20),@NoOfItem varchar(20),@Puls varchar(20),@ModelNo1 varchar(20),@PlanCount int=0,@PlanCount1 int=0,@AlphaCode varchar(20)
DECLARE Cursr CURSOR LOCAL FOR 
select ModelName,CycleTime,CycleTime1,NoofItems,Puls,char(AlphaCode) from tbl_ModuleMaster where MachineGrName=@MachineGroupName and MachineName=@MachineName order by AlphaCode
OPEN Cursr;
FETCH NEXT FROM Cursr INTO @modelNo1,@CycleTime,@CycleTime1,@NoOfItem,@Puls,@AlphaCode	
WHILE @@FETCH_STATUS = 0
BEGIN
	set @i=1
	set @PlanCount=0
	set @PlanCount1=0	
while(@i<=8)
begin
	select @fromTime=item from(select row_number() over(order by (select 1))  as 'SLNO', Item from dbo.SplitString((select TimeWorking from tbl_ShiftMaster where shiftname=@ShiftName and MachineGrName=@MachineGroupName and MachineName=@MachineName),','))XXX where slno=@i
	select @ToTime=item from(select row_number() over(order by (select 1))  as 'SLNO', Item from dbo.SplitString((select TimeWorking from tbl_ShiftMaster where shiftname=@ShiftName and MachineGrName=@MachineGroupName and MachineName=@MachineName),','))XXX where slno=@i+1
if(@i<8)
begin
	insert into #Temp1(Time,PlanCount,ModelName,CycleTime,CycleTime1,PlanCumulative,AlphaCode) values( @fromTime+' - '+@ToTime,
	convert(varchar(20),convert(int,round(convert(decimal(5,1),((3599/convert(decimal(10,5), @CycleTime))))*
	convert(decimal(5,1), @NoOfItem)*convert(decimal(5,1), @Puls),0)))+' - '+convert(varchar(20),convert(int,round(convert(decimal(5,1),((3599/convert(decimal(10,5), @CycleTime1))))*
	convert(decimal(5,1), @NoOfItem)*convert(decimal(5,1), @Puls),0))),@ModelNo1,@CycleTime,@CycleTime1,
	convert(varchar(20),	isnull(@PlanCount,0)+isnull(convert(int,round(convert(decimal(5,1),((3599/convert(decimal(10,5), @CycleTime))))*
	convert(decimal(5,1), @NoOfItem)*convert(decimal(5,1), @Puls),0)),0))+' - '+
	convert(varchar(20),	isnull(@PlanCount1,0)+isnull(convert(int,round(convert(decimal(5,1),((3599/convert(decimal(10,5), @CycleTime1))))*
	convert(decimal(5,1), @NoOfItem)*convert(decimal(5,1), @Puls),0)),0)),@AlphaCode)

	set @PlanCount=@PlanCount+convert(int,round(convert(decimal(5,1),((3599/convert(decimal(10,5), @CycleTime))))*
	convert(decimal(5,1), @NoOfItem)*convert(decimal(5,1), @Puls),0))
	set @PlanCount1=@PlanCount1+convert(int,round(convert(decimal(5,1),((3599/convert(decimal(10,5), @CycleTime1))))*
	convert(decimal(5,1), @NoOfItem)*convert(decimal(5,1), @Puls),0))

end
else if(@i=8)
begin
	set @PlanCount=@PlanCount+convert(int,round(convert(decimal(5,1),((1500/convert(decimal(10,5), @CycleTime))))*
	convert(decimal(5,1), @NoOfItem)*convert(decimal(5,1), @Puls),0))
	set @PlanCount1=@PlanCount1+convert(int,round(convert(decimal(5,1),((1500/convert(decimal(10,5), @CycleTime1))))*
	convert(decimal(5,1), @NoOfItem)*convert(decimal(5,1), @Puls),0))

	insert into #Temp1(Time,PlanCount,ModelName,CycleTime,CycleTime1,PlanCumulative,AlphaCode) values( @fromTime+' - '+	convert(varchar(5),convert(time,dateadd(mi,30,@fromTime))),
	convert(varchar(20),convert(int,round(convert(decimal(5,1),((1500/convert(decimal(10,5), @CycleTime))))*
	convert(decimal(5,1), @NoOfItem)*convert(decimal(5,1), @Puls),0)))+' - '+convert(varchar(20),convert(int,round(convert(decimal(5,1),((1500/convert(decimal(10,5), @CycleTime1))))*
	convert(decimal(5,1), @NoOfItem)*convert(decimal(5,1), @Puls),0))),@ModelNo1,@CycleTime,@CycleTime1,convert(varchar(20), isnull(@PlanCount,0))+' - '+convert(varchar(20), isnull(@PlanCount1,0)),@AlphaCode)
end
set @i=@i+1
end
FETCH NEXT FROM Cursr INTO @modelNo1,@CycleTime,@CycleTime1,@NoOfItem,@Puls,@AlphaCode
END
CLOSE Cursr;
DEALLOCATE Cursr;
select * from #temp1
drop table #temp1

create table #Temp3
(
WorkTime varchar(20),
Alphacode varchar(10),
CreateDate varchar(20),
ModuleName varchar(20)
)


declare @Time varchar(20),@ModelName varchar(20),@AlphaCode1 varchar(20),@Date varchar(20)
DECLARE Cursr CURSOR LOCAL FOR 
--select distinct Time,ModelName,(select char(AlphaCode) from 
--tbl_ModuleMaster where ModelName=orm.ModelName),convert(date,CraetedOn) from tbl_ORMonitoring_1 
--as ORM where 
--shiftname = @ShiftName  and [MachineGroup]=@MachineGroupName and [MachineName]=@MachineName and 
--CraetedOn between @Fromdate and @Todate order by convert(date,CraetedOn),Time
select distinct HourTime,isnull(modelno,0) as ModelName,isnull((select char(AlphaCode) from 
tbl_ModuleMaster where MachineGrName=@MachineGroupName and MachineName=@MachineName and ModelName=ModelNo),0) as AlphaCode,CreatedDate from (Select   HourTime,
 (select distinct isnull( ModelName,0) from #tbl_ORMonitoring_1 or1 where convert(date,or1.shiftStartDate) = convert(date,Orm.shiftStartDate)  and or1.Time=orm.HourTime and 
 or1.Shiftname=orm.Shiftname and or1.[MachineGroup]=Orm.[MachineGroup]and or1.[MachineName]=orm.[MachineName] and ModelName=orm.ModelNo)as ModelNo,
 convert(date,createdon)as CreatedDate from [dbo].#tbl_HourPlan_TotalPlan_1 as orm where shiftname = @ShiftName  and [MachineGroup]=@MachineGroupName and 
 [MachineName]=@MachineName and createdon between @Fromdate and @Todate  )xxx where ModelNo !='0' order by CreatedDate, HourTime


OPEN Cursr;
FETCH NEXT FROM Cursr INTO @Time,@modelName,@AlphaCode1,@Date			
WHILE @@FETCH_STATUS = 0
BEGIN
if(not exists(select * from #temp3 where CreateDate=@Date and worktime= @Time))
begin
insert into #Temp3(WorkTime,Alphacode,CreateDate,ModuleName)values(@Time,@AlphaCode1,@Date,@ModelName)
end
else
begin
update #Temp3 set Alphacode=Alphacode+' + '+@AlphaCode1 where  CreateDate=@Date and worktime= @Time
end
FETCH NEXT FROM Cursr INTO @Time,@modelName,@AlphaCode1,@Date	
END
CLOSE Cursr;
DEALLOCATE Cursr;
select * from #temp3
drop table #temp3

--select  ModelName,MachineTime,Problem_Count,CreatedDate, ProblemName +' Problem has defined by user at '+MachineTime+' Hour and Model Name is '+ModelName+
--',this Problem is effected to '+convert(varchar(20),Problem_Count)+' Items, At '+ MachineTime +' Hour' as 'Problem' from (select MachineTime, 
--count(Problem_Code) as Problem_Count,Problem_Code,MachineName,ModelName,convert(date,CreatedDate) as CreatedDate,
--(select isnull(Problem_type,'') from tbl_ProblemDefectMaster where MachineGrName=CT.MachineGroup and MachineName=ct.MachineName 
--and OperationCode=ct.Problem_Code) as 'ProblemName' from tbl_CycleTimeCalc_1 as CT where CreatedDate between @Fromdate and @Todate and ShiftName=@ShiftName and
-- MachineGroup=@MachineGroupName and MachineName=@MachineName  group by ModelName, MachineGroup,MachineName, MachineTime, Problem_Code,convert(date,CreatedDate),ShiftName)xxx where ProblemName is not null order by CreatedDate

-- declare @Temp4 Table(MachineTime varchar(20),OperationName varchar(200),Createdate varchar(20))
--Insert @Temp4(MachineTime,OperationName,Createdate)(select distinct MachineTime,OperationName,CreatedDate from
--( select   CT.MachineTime,max(replace(CT.[Differene],'-','')) as [Differene],CT.ModelName,convert(date,CT.CreatedDate) as CreatedDate,
--CT.ShiftName ,(select  OperationName from tbl_ProblemDefectMaster  as PD where  PD.MachineGrName=CT.MachineGroup and PD.MachineName=CT.MachineName 
--and PD.OperationCode=ISNULL(CT.Problem_Code,'')) as OperationName  
--from tbl_CycleTimeCalc_1   as CT where CT.CreatedDate between @Fromdate and @Todate and CT.ShiftName=@ShiftName and
-- CT.MachineGroup=@MachineGroupName and CT.MachineName=@MachineName  and CT.MachineTime is not null group by 
-- ModelName, MachineGroup,MachineName, MachineTime, Problem_Code,convert(date,CreatedDate),ShiftName  )xxx)  

--(select distinct MachineTime ,Createdate as CreatedDate,STUFF((Select ','+OperationName from @Temp4 T1 where T1.MachineTime=T2.MachineTime and t1.Createdate=t2.Createdate
-- FOR XML PATH('')),1,1,'') as Problem from @Temp4 T2)

  declare @Test Table(MachineTime varchar(20),OperationName varchar(200),Createdate varchar(20),TotalTime varchar(20))
Insert @Test(MachineTime,Createdate,OperationName,TotalTime)( select   orm.HourTime,
case when (orm.HourTime !='23:30') and orm.ShiftName='third shift' then convert(varchar(20), dateadd(day,-1,convert(date,orm.createdon)),106) 
else convert(varchar(20), convert(date,orm.createdon),106) end,
(select  isnull(OperationName,'') from tbl_ProblemDefectMaster  as PD where  PD.MachineGrName=orm.MachineGroup and PD.MachineName=orm.MachineName 
and PD.OperationCode in (select  ISNULL(Problem_Code, '0') from (SELECT top 1  max(convert(decimal,replace(CT.[Differene],'-',''))) as [Differene] ,
isnull(Problem_Code,'0') as Problem_Code
from tbl_CycleTimeCalc_1   as CT where CONVERT(DATE,CT.CreatedDate) =CONVERT(DATE,ORM.createdon) and CT.ShiftName=orm.ShiftName and
 CT.MachineGroup=orm.[MachineGroup] and CT.MachineName=orm.[MachineName] and CT.MachineTime=orm.HourTime   and CT.MachineTime is not null  
 group by TotalSeonds, Problem_Code having max(convert(decimal,replace(CT.[Differene],'-','')))>0 order by [Differene] desc )xxx)),
 (select  ISNULL(TotalSeonds, '0') from (SELECT top 1  max(convert(decimal,replace(CT.[Differene],'-',''))) as [Differene] ,
isnull(TotalSeonds,'0') as TotalSeonds
from tbl_CycleTimeCalc_1   as CT where CONVERT(DATE,CT.CreatedDate) =CONVERT(DATE,ORM.createdon) and CT.ShiftName=orm.ShiftName and
 CT.MachineGroup=orm.[MachineGroup] and CT.MachineName=orm.[MachineName] and CT.MachineTime=orm.HourTime   and CT.MachineTime is not null  
 group by TotalSeonds having max(convert(decimal,replace(CT.[Differene],'-','')))>0 order by [Differene] desc )xxx)
  from [dbo].tbl_HourPlan_TotalPlan_1 as orm where orm.createdon between @Fromdate and @Todate and orm.ShiftName=@ShiftName and
   orm.shiftname = @ShiftName  and orm.[MachineGroup]=@MachineGroupName and orm.[MachineName]=@MachineName  
   group by   HourTime,Shiftname,MachineGroup,MachineName,convert(date,orm.createdon)	
  )  
  
(select distinct MachineTime ,Createdate as 'CreatedDate',STUFF((Select ','+ isnull(OperationName,'')  from @Test T1 where T1.MachineTime=T2.MachineTime and t1.Createdate=t2.Createdate
 FOR XML PATH('')),1,1,'') +'. Total Loss Hour - '+ CONVERT(VARCHAR(2), TotalTime / 60 % 60) 
+ ':' + CONVERT(VARCHAR(2), TotalTime % 60) as 'Problem' from @Test T2)

 drop table #tbl_CycleTimeCalc_1
drop table #tbl_HourPlan_TotalPlan_1
drop table #tbl_ORMonitoring_1

end
if(@Type='CycleTimeFlactuationForGraph')
begin
exec ('select ''Model Name : ''+ [ModelName] as ModelNo,[CycleTime],convert(int,[TotalSeonds]) as TotalTime,convert(int, row_number() over(order by (select 1) desc) ) as ''SLNO'',
''Shift Name : ''+[ShiftName] as ''ShiftName'' , ''Line Group : ''+ MachineGroup as LineGroup,''Line Name : ''+ MachineName as LineName,''From '+@Fromdate+' To '+@Todate+''' as ''Date'' from [dbo].[tbl_CycleTimeCalc_1] where 
 MachineTime in ('+@MachineTime+') and ModelName ='''+@ModelNo+''' and  shiftname = '''+@ShiftName+''' and MachineGroup='''+@MachineGroupName+''' and MachineName='''+@MachineName+''' 
   and  [CreatedDate] between '''+@Fromdate+''' and '''+@Todate+''' and [TotalSeonds]<500')
end
if(@Type='CycleTimeFlactuation')
begin
exec ('select [ModelName] as ModelNo,[CycleTime],[MachineTime] as Time,[FromTime] as StartTime,[ToTime] as EndTime,[TotalSeonds] as TotalTime,
[Differene] as Differences ,[ShiftName], MachineGroup as LineGroup,MachineName as LineName,''From '+@Fromdate+' To '+@Todate+''' as ''Date'',convert(varchar(30), CreatedDate,113) as CreatedDate from [dbo].[tbl_CycleTimeCalc_1] where 
   ModelName in ('+@ModelNo+') and  shiftname in ('+@ShiftName+') and MachineGroup='''+@MachineGroupName+''' and MachineName='''+@MachineName+''' and [CreatedDate] between '''+@Fromdate+''' and '''+@Todate+''' order by CreatedDate  ')
end
if(@Type='CallandResponse')
begin
--select 'lkkkk'
exec ('select convert(varchar(20),[CreatedOn],113) as StartTime,convert(varchar(20),ResolvedOn,113) as EndTime,
 convert(varchar(20), datediff(s,[CreatedOn],ResolvedOn)/3600)+'':''+
	convert(varchar(20), datediff(s,[CreatedOn],ResolvedOn)%3600/60)+'':''+	convert(varchar(20), datediff(s,[CreatedOn],ResolvedOn)%60) as  TotalTime, [Station],[AndonType],[Time],[ModelName] as ModelNo ,
	[ShiftName], MachineGroup as LineGroup, MachineName as LineName,''From '+@Fromdate+' To '+@Todate+''' as ''Date'',convert(varchar(50),CreatedOn) as CreatedOn from [dbo].[tbl_AndonCall_1] where 
station in ('+@Station+') and  shiftname in ('+@ShiftName+') and 
MachineGroup='''+@MachineGroupName+''' and MachineName='''+@MachineName+''' and [CreatedOn] between '''+@Fromdate+''' and '''+@Todate+''' group by CreatedOn,ResolvedOn,Station,AndonType,time,ModelName,Shiftname,MachineGroup,MachineName')
end
if(@Type='kanbanAchievement')
begin
--select 'lkkkk'
select count(*) as 'noofkanban', ModelName,sum(convert(int,qty)) as Planqty,PartNo,ShiftName,MachineGroup as LineGroup,MachineName as LineName,
(select sum(convert(int,ORM.HourQty)) from tbl_ORMonitoring_1 as ORM where ORM.[MachineGroup]=@MachineGroupName 
and orm.[MachineName]=@MachineName and orm.[ModelName]=KP.ModelName and orm.CraetedOn between @Fromdate and @Todate and orm.ShiftName=@ShiftName) as actualQty  ,
'From '+@Fromdate+' To '+@Todate as 'Date',CONVERT(VARCHAR(20),Createon ,106) as createon
from tbl_kanbanprogress_1 as KP where kp.MachineGroup=@MachineGroupName and kp.MachineName=@MachineName and kp.Createon between @Fromdate and @Todate
and kp.ShiftName=@ShiftName
group by ModelName ,partno,shiftname,MachineGroup,MachineName,createon
end
end try
begin CATCH
SELECT ERROR_MESSAGE()
END CATCH
if(@Type='LossHour')
begin
--select 'lkkkk'
begin try
select  row_number() over(order by (select 1))  as 'SLNO', MachineGroup as LineGroup,MachineName as LineName, isnull(CONVERT(DECIMAL(5,2), Total),0) as Total,ISNULL(ManPower,0) AS ManPower,ISNULL(ManHour,0)AS ManHour,Problem_Code ,ProblemName  ,FromTime +' - '+ ToTime as 'StopedTime',ShiftName ,'From '+@Fromdate+' To '+@Todate as 'Date' 
from tbl_CycleTimeCalc_1 where  [MachineGroup]=@MachineGroupName and [MachineName]=@MachineName and Shiftname=@ShiftName  
and CreatedDate between @fromdate and @todate  and Differene<-10 order by RefNo

end try
begin CATCH
SELECT ERROR_MESSAGE()
END CATCH
end
if(@Type='GetLineNames')
begin
begin try
select distinct MachineName,'False' as Flag from tbl_MachineGroup
Select HeaderType from tbl_KpiManHrs_Ratio_Type where ReportTYpe='ManHour'
Select HeaderType from tbl_KpiManHrs_Ratio_Type where ReportTYpe='RATIO'
end try
begin CATCH
SELECT ERROR_MESSAGE()
END CATCH
end
if(@Type='KPI')
begin
begin try
   declare @TableType varchar(20),@ColumnName varchar(200)

if(@ReportType='Man-Hour')
begin

   select @TableType=Nametype,@ColumnName=OrginalName from tbl_KpiManHrs_Ratio_Type where ReportType='ManHour' AND HeaderType=@KPIHeaderType
 if(@TableType='KPI')
   begin
	 exec ('select isnull(sum(convert(decimal(10,2), case when '+@ColumnName+' ='''' then ''0'' else '+@ColumnName+' end )),0) as ManHour,
	 upper('''+ @KPIHeaderType+''') as ''HeaderType'' ,MachineName from tbl_KPIEntry where MachineName in ('+@MachineName+') 
	 and CreatedOn between '''+@Fromdate+''' and '''+@Todate+''' group by MachineName')
   end
   else
   begin
	  exec (' select isnull(sum(convert(decimal(10,2), ManHour)),0) as ManHour,upper('''+ @KPIHeaderType+''') as HeaderType ,MachineName 
	  from [dbo].[tbl_CycleTimeCalc_1] where MachineName in ('+@MachineName+') AND CreatedDate between '''+@Fromdate+''' and '''+@Todate+''' 
	   and ProblemName in (select ProblemName from tbl_ProblemDefectMaster where Problem_type = '''+@ColumnName+''') group by MachineName')
   end
end
if(@ReportType='Ratio')
begin

   select @TableType=Nametype,@ColumnName=OrginalName from tbl_KpiManHrs_Ratio_Type where ReportType='RATIO' AND HeaderType=@KPIHeaderType
  if(@TableType='KPI')
   begin
	 EXEC ('select isnull(sum(convert(decimal(10,2), case when '+@ColumnName+' ='''' then ''0'' else '+@ColumnName+' end )),0) as Ratio,
	 upper('''+ @KPIHeaderType+''') as ''HeaderType'' ,MachineName from tbl_KPIEntry where MachineName in ('+@MachineName+') 
	 and CreatedOn between '''+@Fromdate+''' and '''+@Todate+''' group by MachineName')
   end
   else
   begin
	   exec (' select isnull(sum(convert(decimal(10,2), ManHour)),0) as Ratio,upper('''+ @KPIHeaderType+''') as HeaderType ,MachineName 
	  from [dbo].[tbl_CycleTimeCalc_1] where MachineName in ('+@MachineName+') AND CreatedDate between '''+@Fromdate+''' and '''+@Todate+''' 
	   and ProblemName in (select ProblemName from tbl_ProblemDefectMaster where Problem_type = '''+@ColumnName+''') group by MachineName')   end
end

end try
begin CATCH

	SELECT ERROR_MESSAGE()
END CATCH
end











